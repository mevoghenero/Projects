<?php $page = basename($_SERVER['SCRIPT_NAME']); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Examvilla.com.ng - WAEC, NECO, JAMB, NABTEB, IJMB & CAMBRIDGE Examination Expo Panel </title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1">
    <meta name="google-site-verification" content="ZOT_v_jpTUQ7R0hHiR5e8a7uFFJArtf1iNIKI5rAWyI" />
    <meta name="google-site-verification" content="zxrmQyCKXxw9bRxr_TewFuDSlbIOl90KnkSNnAlt6NA" />
    <meta property="og:locale" content="en_US" />
    <meta property="og:type" content="website" />
    <meta property="og:title" content="WAEC, NECO, JAMB, NABTEB, IJMB & CAMBRIDGE Examination Expo Panel" />
    <meta property="og:description" content="EXAMVILLA PROVIDE QUALITY ASSURANCE OF MAKING YOUR PAPERS IN ONE SITTING INCLUDING JAMB, WAEC, NECO, GCE" />
    <meta property="og:url" content="https://examvilla.com.ng/" />
    <meta property="og:site_name" content="Examvilla" />
    <meta property="og:image"/>
    <meta property="og:image:secure_url" />

    <link rel="icon" type="image/gif" href="public/icon.png" />
    <link rel="stylesheet" type="text/css" href="public/style.css">
    <!--  <link rel="stylesheet" type="text/css" href="public/materialize.css"> -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">
    <script type='text/javascript' src='//platform-api.sharethis.com/js/sharethis.js#property=5b70620839f9520011ecfcc1&product=inline-share-buttons' async='async'></script>
    
    <!-- Ck Editor-->
   <script src="//cdn.ckeditor.com/4.11.4/full/ckeditor.js"></script>
   
   
    <style type="text/css">
    .examtable {font-size:12px;color:#333333;width:100%;border-width: 1px;border-color: #729ea5;border-collapse: collapse;}
    .examtable th {font-size:12px;background-color:#acc8cc;border-width: 1px;padding: 8px;border-style: solid;border-color: #729ea5;text-align:left;}
    .examtable tr {background-color:#d4e3e5;}
    .examtable td {font-size:12px;border-width: 1px;padding: 8px;border-style: solid;border-color: #729ea5;}
    .examtable tr:hover {background-color:#ffffff;}
</style>
</head>
<body>
    <div id="sheader">
        <div class="header"> ExamVilla.Com.Ng</div>
        <div class="info">Success Is Not A Must!!!
            <form method="post" action="epage.php" style="margin:10px;">
                <input type="password" name="pin" placeholder="Enter pin">
                <input class="p_input" type="submit" name="access" value="Get Answers">
            </form>
        </div>
        <div class="nav">
            <a <?php if($page == 'index.php') { echo " id='active' "; }?> class="legend" href="index.php">Home</a> &middot;
            <a <?php if($page == 'epage.php') { echo " id='active' "; }?> class="legend" href="epage.php">Enter Pin</a> &middot; 
            <a <?php if($page == 'xprice.php') { echo " id='active' "; }?> class="legend" href="xprice.php">Subject Prices</a> 
            <!-- &middot; <a href="tutorials"><span style="color:white">Tutorials</span></a>                 -->
        </div>
    </div>
</div>