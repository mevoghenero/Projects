<?php
/* IMPORTANT FILES */
include "modules.php";

$pageTitle="examsss";
$err="";
include "content.php";


$examID=(int)$_GET['id'];
$action=strtolower($_GET['action']);
if(!$examID and isloggedin()){
    header("location:$domain/exams.php");
    exit;
} elseif(!$examID and !isloggedin()){
    header("location:$domain");
    exit;
}
else {
    $q=$conn->query("SELECT * FROM examp WHERE id=$examID") or die(mysqli_error($conn));
    if(mysqli_num_rows($q)==0){
        header("location:$domain");
        exit;
    }
    else{
        $ft=mysqli_fetch_object($q);
        $post=$ft->post;
        $exid=$ft->examid;
    }
    if($action=="edit"){
        if(isset($_POST['save'])){
            $msg=$_POST['message'];
            if(!$msg){
                $err="Please enter something";
            } else {
                $qu=$conn->query("UPDATE examp SET post='$msg' WHERE id=$examID") or die(mysqli_error());
                header("location:page.php?id=$exid");
                exit;
            }
        }
        $content=<<<EOF
        <div class="passwordEnter">
            <div style="color:red; font-size:32px;">$err</div>
            <center>Edit Post</center><br><br>
            <form method="post" action="">
                <textarea name="message" cols="20" rows="4">$post</textarea>
                <br><br>
                <input type="submit" name="save" value="Edit Post">
            </form>
        </div>
EOF;
    }
    elseif($action=="del"){
        if(isset($_POST['del'])){
            $qu=$conn->query("DELETE FROM examp WHERE id=$examID") or die(mysqli_error($conn));
            header("location:page.php?id=$exid");
            exit;
        }
        $content=<<<EOF
        <div class="passwordEnter">
            Are you sure you want to delete this content?<br><br>
            <form method="post" action="">
                <input type="submit" name="del" value="Yes, Delete">
            </form><br>
            <input type="submit" value="No, Go Back" onclick="window.location='page.php?id=$exid'">
        </div>
EOF;
}
}
echo $content;
?>