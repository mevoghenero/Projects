<?php
/* IMPORTANT FILES */
include "modules.php";

$id=(int)$_GET['id'];
if(!$id or !isloggedin()){
    header("location: index.php");
    exit;
} else {
    $err="";
    if(isset($_POST['edit'])){
        $etitle=$_POST['title'];
        $econtent=$_POST['content'];
        if(!$etitle or !$econtent){
            $err="<font style='color:red; font-size:32px;'>An error occured</font><br>";
        } else {
            $dq=$conn->query("UPDATE updates SET topic='$etitle', content='$econtent' WHERE id=$id") or die($conn->error);
            $err="<font style='color:green; font-size:32px;'>Saved!</font><br>";
        }
    }
    $q=$conn->query("SELECT * FROM updates WHERE id='$id'") or die($conn->error);
    if($q->num_rows>0){
        $load=$q->fetch_object();
        $title=$load->topic;
        $content=$load->content;
        $time=date("jS F M", $load->postdate);
        $hits=$load->hits;
        
        #update hits
        $nhit=$hits+1;
        $qq=$conn->query("UPDATE updates SET hits=$nhit WHERE id=$id") or die($db->error);
        
        $pTitle=$title;
    } else {
        header("location:index.php");
    }
}
include "content.php";


?>
<h1>Edit <?=$title?></h1>

<div class="itemContainer center">
    <form method="post" action="">
        <?=$err?>
        Title:<br>
        <input type="text" name="title" value="<?=$title?>">
        <br>Content:<br>
        <textarea name="content" id="editor"><?=htmlspecialchars($content)?></textarea><br>
        <input type="submit" name="edit" value="Save">
    </form>
</div>
<script>
    CKEDITOR.replace( 'editor' );
  </script>

<?php include "footer.php";?>