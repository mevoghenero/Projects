<?php
/* IMPORTANT FILES */
include "modules.php";

$pageTitle=$Ptitle;

include "content.php";
if(isloggedin()){
    header("location:admin-p.php");
}
$err="";
if(isset($_POST['access'])){
    $pin=$_POST['pin'];
    $q=$conn->query("SELECT * FROM exam WHERE pass='$pin' ORDER BY id DESC LIMIT 1") or die($conn->error);
    if($q->num_rows>0){
        $load=$q->fetch_object();
        $eid=$load->id;
        $_SESSION['pin']=$pin;
        header("location:page.php?id=$eid");
        exit;
    } else {
        $err="Invalid passkey, please enter a correct pin sent to by Admin!!<br><br>";
    }
}
?>
<h3 style="text-align: center">ENTER PASSKEY CODE</h3>
<br><br>
<div class="passwordEnter">
    <div style="color:red; font-size:32px;"><?=$err?></div>
    <form method="post" action="">
        Pin:<br>
        <input type="password" name="pin"><br><br>
        <input type="submit" name="access" value="Get Answers">
    </form>
</div>

<?php include "footer.php"; ?>