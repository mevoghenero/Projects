<?php
/* IMPORTANT FILES */
include "modules.php";
if(!isloggedin()){
    header("location:$domain/index.php");
    exit;
}
$pTitle="Latest Updates";
include "content.php";
#load updates
$mq=$conn->query("SELECT * FROM updates") or die($conn->error);
$limit=15;
$rows=$mq->num_rows;
$totalpages=ceil($rows/$limit);
$pagin='<div class="paging">';
$page=@(int)$_GET['page'];
if($page<1 or !$page) $page=1;
if($page>$totalpages) $page=$totalpages;
$offset=($page-1)*$limit;
$prev=$page-1; $next=$page+1;
$pagin.="[Page: $page of $totalpages]";
if($page>1) $pagin.=" / [<a href=\"?page=$prev\">Prev</a>]";
if($page<$totalpages) $pagin.=" / [<a href=\"?page=$next\">Prev</a>]";
$page_="";
$q=$conn->query("SELECT * FROM updates ORDER BY id DESC LIMIT $offset,$limit") or die($conn->error);
if($q->num_rows==0){
    $page_="No updates yet";
} else {
    while($load=$q->fetch_object()){
        $uid=$load->id;
        $topic=$load->topic;
        $page_.='- <a href="edit-upd.php?id='.$uid.'">'.$topic.'</a><br>';
    }
}
$page_.="$pagin</div>";
?>
<div class="space" style="margin:15px;">
            <b>
                Manage Updates
            </b>
        </div>
<div class="updates">
    <?=$page_?>
</div>

<?php include "footer.php"; ?>