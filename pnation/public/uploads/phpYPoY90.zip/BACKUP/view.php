<?php
/* IMPORTANT FILES */
include "modules.php";

$id=(int)$_GET['id'];
if(!$id){
    header("location: index.php");
    exit;
} else {
    $q=$conn->query("SELECT * FROM updates WHERE id='$id'") or die($conn->error);
    if($q->num_rows>0){
        $load=$q->fetch_object();
        $title=$load->topic;
        $content=bb_code($load->content);
        $time=date("jS F M", $load->postdate);
        $hits=$load->hits;
        
        #update hits
        $nhit=$hits+1;
        $qq=$conn->query("UPDATE updates SET hits=$nhit WHERE id=$id") or die($db->error);
        
        $pTitle=$title;
    } else {
        header("location:index.php");
    }
}
include "content.php";


?>
<div class="bleft"><h1><?=$title?></h1></div>
<div class="bmain">
    <div class="space ddd">
        Posted by Legendary on <?=$time?> &raquo; <?=$hits?> views
    </div></div>
    <div class="bbottom"></div>

    <div class="upd-content">
        <div class="col-md-12 col-xs-12">
            <div class="well">
                <?=rtrim(html_entity_decode(strip_tags($content)))?>

                <br>
                <br>
                <div class="sharethis-inline-share-buttons"></div>
            </div>
        </div>
    </div>
    <!--  <div class="sharethis-inline-reaction-buttons"></div> -->

    <?php include "footer.php";?>