<?php include "content.php"; ?>

<br>
<div class="col-md-12 col-xs-12">
<div class="well">
<div align="center"><span style="font-weight: 700; font-family: sans-serif; font-size: medium; background-color: rgb(245, 245, 245);"><div class="bmenu" style="color: rgb(255, 255, 255); background-color: #087eb7; background-repeat: repeat-x; background-position: 50% top; margin-top: 1px; margin-bottom: 1px; padding: 2px; border: 1px solid rgb(224, 230, 255);"><h1>WAEC/NECO/NABTEB DAILY SUBSCRIPTION</h1></div></span></div>
<div><span style="font-weight: bold; text-decoration-line: underline;"><br /></span></div>
<font color="black"><i>SUBSCRIBING BEFORE THE EXAM DAY MAKES YOU SAFER BECAUSE YOU'LL GET PASSWORD EARLIER ON THAT EXAM DAY. ALWAYS SUBSCRIBE A DAY BEFORE EACH EXAM.</i></font><br />
<br />
Confirmation SMS Will Be Sent To You After Your Subscription.<br />
Subscribing For More Than One subject at A time is also allowed.<br />
Subscribing For whatsapp is also allow and it's more preferable.<br />
<br />
<b><font color="red">ATTENTION:-</font> PLEASE AFTER SENDING YOUR CARD DO NOT THROW THEM AWAY UNTIL YOU RECEIVE A CONFIRMATION MESSAGE FROM US.</b><br />
<br />
<font color="red">FOR PAYMENT PER SUBJECT</font><br />
<br />
<p id="e-title">Available Subjects & Prices:</p>
<br/>
<div class="table-responsive">          
  <table class="table">
    <thead>
      <tr>
        <th>Subjects</th>
        <th>Direct SMS</th>
        <th>Online PIN</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>English</td>
        <td>&#8358;1,000</td>
        <td>&#8358;600</td>
      </tr>
      <tr>
        <td>Mathematics</td>
        <td>&#8358;1,000</td>
        <td>&#8358;600</td>
      </tr>
      <tr>
        <td>Biology</td>
        <td>&#8358;800</td>
        <td>&#8358;400</td>
      </tr>
      <tr>
        <td>Physics</td>
        <td>&#8358;800</td>
        <td>&#8358;400</td>
      </tr>
      <tr>
        <td>Chemistry</td>
        <td>&#8358;800</td>
        <td>&#8358;400</td>
      </tr>
      <tr>
        <td>Geography 1</td>
        <td>&#8358;800</td>
        <td>&#8358;400</td>
      </tr>
      <tr>
        <td>Geography 2</td>
        <td>&#8358;800</td>
        <td>&#8358;400</td>
      </tr>
      <tr>
        <td>Literature 1</td>
        <td>&#8358;800</td>
        <td>&#8358;400</td>
      </tr>
      <tr>
        <td>Literature 2</td>
        <td>&#8358;800</td>
        <td>&#8358;400</td>
      </tr>
      <tr>
        <td>Crs/Irs</td>
        <td>&#8358;800</td>
        <td>&#8358;400</td>
      </tr>
      <tr>
        <td>Government</td>
        <td>&#8358;800</td>
        <td>&#8358;400</td>
      </tr>
      <tr>
        <td>Commerce</td>
        <td>&#8358;800</td>
        <td>&#8358;400</td>
      </tr>
      <tr>
        <td>Economics</td>
        <td>&#8358;800</td>
        <td>&#8358;400</td>
      </tr>
      <tr>
        <td>Further Maths</td>
        <td>&#8358;800</td>
        <td>&#8358;400</td>
      </tr>
      <tr>
        <td>Accounting</td>
        <td>&#8358;800</td>
        <td>&#8358;400</td>
      </tr>
      <tr>
        <td>Marketing</td>
        <td>&#8358;800</td>
        <td>&#8358;400</td>
      </tr>
      <tr>
        <td>Agric Science</td>
        <td>&#8358;800</td>
        <td>&#8358;400</td>
      </tr>
      <tr>
        <td>Data Processing</td>
        <td>&#8358;800</td>
        <td>&#8358;400</td>
      </tr>
      <tr>
        <td>Civic Education</td>
        <td>&#8358;800</td>
        <td>&#8358;400</td>
      </tr>
      <tr>
        <td>Animal Husbandry</td>
        <td>&#8358;800</td>
        <td>&#8358;400</td>
      </tr>
      <tr>
        <td>Office Practice</td>
        <td>&#8358;800</td>
        <td>&#8358;400</td>
      </tr>
      <tr>
        <td>ICT</td>
        <td>&#8358;800</td>
        <td>&#8358;400</td>
      </tr>
    </tbody>
  </table>
  </div>
<br/>
<br/>
<p id="e-title">Available Practicals & Prices:</p>
<br/>
<div class="table-responsive">          
  <table class="table">
    <thead>
      <tr>
        <th>Subjects</th>
        <th>Direct SMS</th>
        <th>Online PIN</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>Biology</td>
        <td>&#8358;600</td>
        <td>&#8358;300</td>
      </tr>
      <tr>
        <td>Physics</td>
        <td>&#8358;600</td>
        <td>&#8358;300</td>
      </tr>
      <tr>
        <td>Chemistry</td>
        <td>&#8358;600</td>
        <td>&#8358;300</td>
      </tr>
      <tr>
        <td>Agric Science</td>
        <td>&#8358;600</td>
        <td>&#8358;300</td>
      </tr>
      <tr>
        <td>Animal Husbandry</td>
        <td>&#8358;600</td>
        <td>&#8358;300</td>
      </tr>
    </tbody>
  </table>
  </div>
<br/>
<br/>
<p id="e-title">Please NOTE:</p><p id="about-ex">
<strong>DIRECT SMS:</strong> These are candidates that receives their answers as SMS(Both OBJ & Theory).<br/>
They receive typed answers through SMS.<br/>
<br/>
<strong>ONLINE PIN/PASSWORD:</strong>
These are candidates that receive a password/pin to view answers posted on our answer page.<br/>
They must have a working network to enable them to browse. Only OBJ will be sent directly on their phones while they keep refreshing the answer page to get the essay/theory part.<br/>
<br/><strong>WE ONLY ACCEPT MTN CARDS AS MODE OF PAYMENT</strong>
</p>
<br/>
<br/>
<font color='red'>Send Your Subject Name + Your Phone Number with the Card PIN(S) to <strong>07067172511</strong> <br />
Subscription Closes 2hrs Before Each Paper.</font> <font color='red'><b>Make Sure You Include Your Subject(s) While Subscribing</b>.</font><br />
<br />
<br />
<b><font color="darkred">NOTE:-<br />
PLEASE DON'T CALL US!.<br />
WE ACCEPT ONLY TEXT MESSAGES.<br />
OUR NUMBER IS NOT AVAILABLE FOR CALLS BUT CAN RECEIVE AND REPLY TEXT MASSAGES ONLY.<br />
Always Send Us SMS Of Your Complaint.</font></b><br/>
<br />
Warning!!!. Use Only Mtn Or 9mobile Line To Subscribe For Direct SMS<br />
<br />
Legendary <br />
<strong>07067172511</strong>
</div>
</div>

<?php include('footer.php'); ?>