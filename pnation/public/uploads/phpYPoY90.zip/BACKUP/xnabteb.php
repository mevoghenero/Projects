<?php include "content.php"; ?>
<br>
<div class="col-md-12 col-xs-12">
	<div class="well">
		<div align="center"><span style="font-weight: 700; font-family: sans-serif; font-size: medium; background-color: rgb(245, 245, 245);"><div class="bmenu" style="color: rgb(255, 255, 255); background-color: #087eb7; background-repeat: repeat-x; background-position: 50% top; margin-top: 1px; margin-bottom: 1px; padding: 2px; border: 1px solid rgb(224, 230, 255);"><h1>GCE [JAN/FEB $ NOV/DEC] RUNS</h1></div></span></div>
		<div><span style="font-weight: bold; text-decoration-line: underline;"><br /></span></div>
		<div><span style="font-weight: bold; text-decoration-line: underline;">BENEFIT OF PAYMENT BEFORE EXAM:</span></div>
		<div>(i)You are automatically a VIP.</div>
		<div>(ii)You will be registered on our&nbsp;where u can confirm ur subjects to make sure there is no mistake on your subjects</div>
		<div>(iii)You will get special attention from us.</div>
		<div>(iv)We can call or text you anytime if any update comes up.</div>
		<div>NOTE: The Price May increase, Early Payment is Good</div>
		<div><br /></div>
		<div><span style="text-decoration-line: underline; font-weight: bold;">LISTS OF AVAILABLE SUBJECTS FOR NABTEB RUNS</span></div>
		<div>English</div>
		<div>Maths</div>
		<div>Biology</div>
		<div>physics</div>
		<div>Chemistry</div>
		<div>Literature</div>
		<div>Govenment</div>
		<div>Geography</div>
		<div>Economics</div>
		<div>Commerce</div>
		<div>Accounting</div>
		<div>Agric</div>
		<div>Further Maths</div>
		<div>CRK/IRK</div>
		<div>Igbo</div>
		<div>Yoruba</div>
		<div>Hausa</div>
		<div><br /></div>
		<div>NEWLY INTRODUCE SUBJECT</div>
		<div>Office Pratical</div>
		<div>Marketing</div>
		<div>Insurance</div>
		<div>I.C.T</div>
		<div>Civic Education (<span style="color: rgb(255, 0, 0);">Compulsory</span>)</div>
		<div>Data Processing</div>
		<div>Health Science</div>
		<div>Computer Studies</div>
		<div>Health Education</div>
		<div><br /></div>
		<div><span style="font-weight: bold; text-decoration-line: underline; color: rgb(255, 0, 0);">Available Practicals</span></div>
		<div>Agric</div>
		<div>Physics</div>
		<div>Chemistry</div>
		<div>Biology</div>
		<div><br /></div>
		<div>(i)&nbsp;<span style="color: rgb(255, 0, 0);">DIRECT MOBILES RUNS</span>:-</div>
		<div>This is a plan where we will send you the answers both obj &amp; theory direct to your mobile phone inbox as SMS. It cost&nbsp;<span style="color: rgb(0, 0, 255);">N7,000</span>&nbsp;for your full 9 subjects including Practicals.</div>
		<div><br /></div>
		<div>(ii)&nbsp;<span style="font-weight: bold; color: rgb(255, 0, 0);">PASSWORD/LINK RUNS</span>:- 
			<div>In this plan you get Sms to your phone with a link/password to where Obj &amp; theory answers are posted online. It cost&nbsp;<span style="color: rgb(0, 0, 255);">N4,000</span>&nbsp;for your full 9 subjects including Practicals.</div>
			<div><br /></div>
			<div>(iii) DIRECT MOBILE FOR ALL SUBJECTS + practicals VIP Treat:&nbsp;<span style="color: rgb(0, 0, 255);">N14,000</span></div>
			<div>(This is for those that wants both Science &amp; Arts i.e Wapmasters, Center Owners Those that have candidates)</div>
			<div><br /></div>
			<div>(iv) PASSWORD/LINK FOR ALL SUBJECTS + practicals VIP Treat:&nbsp;<span style="color: rgb(0, 0, 255);">N7,000</span></div>
			<div>(This is for those that wants both Science &amp; Arts i.e Wapmasters, Center Owners Those that have candidates)</div>
			<div><br /></div>
			<div>PAYMENT IS DONE THROUGH MTN CARDS ONLY !!</div>
			<div><br /></div>
			<div><span style="color: rgb(255, 0, 0);">HOW TO SUBSCRIBE:</span>&nbsp;</div><div>Send the following to <b>07067172511</b>:</div>
			<div>(i) MTN CARD PINS&nbsp;</div>
			<div>(ii) Amount Paid</div>
			<div>(iii) Subjects</div>
			<div>(iv) Your Name + Your Phone number&nbsp;</div>
			<div><br /></div>
			<div>SCORE IN VIEW</div>
			<div>We are Assuring You a Quality Score of&nbsp;<span style="color: rgb(255, 0, 0);">A</span>,&nbsp;<span style="color: rgb(0, 0, 255);">B</span>&nbsp;&amp;&nbsp;<span style="color: rgb(255, 0, 255);">C</span>&nbsp;</div>
			<div>&nbsp;</div>
			<div><span style="font-weight: bold; text-decoration-line: underline; color: rgb(255, 0, 0);">RUNS PATTERN</span>:</div>
			<div>-For Direct Mobile Subscribers Gets Answers Directly on their phones AT LEAST 30mins Before exam commence.....</div>
			<div>-Link Subcribers gets Link of where answers are posted online.</div>
			<div>-YOU WILL RECEIVE CONFIRMATION TEXT IN THE NIGHT AFTER YOUR PAYMENT.</div>
			<div>-BOTH LINK, WHATSAPP AND DIRECT SMS SUBSCRIBERS GETS THEIR PACKAGE AT THE SAME TIME!</div>
			<div>-NO MORE OPENING OF ANSWER PAGE FOR PUBLIC VIEW!</div> </div>

			<br>
			<div class="sharethis-inline-share-buttons"></div>
		</div>
	</div>

	<?php include("footer.php"); ?>