<?php
/* IMPORTANT FILES */
include "modules.php";

$pageTitle="examsss";

include "content.php";

//admin sign up
    $err="";
    $countUx=$conn->query("SELECT * FROM admin LIMIT 1");
    $countU=mysqli_num_rows($countUx);
if(isset($_POST['reg'])){
    $username=$_POST['name'];
    $pass1=$_POST['p1'];
    $pass2=$_POST['p2'];
    $tel=$_POST['ph'];
    $sc=$_POST['sc'];
    $error=array();
    if($countU==0){
        $secret_key=rand(1111,9999);
    } else {
        $ft=mysqli_fetch_object($countUx);
        $osc=$ft->secret_key;
        if(empty($sc) or $sc!==$osc){
            $error[]="Incorrect Secret Key";
        }
    }
    
    if(empty($username)){
        $error[]="Please enter a username";
    }
    elseif(strlen($username)>20){
        $error[]="Username too short";
    }
    if(empty($pass1) or $pass1!==$pass2){
        $error[]="Password do not match";
    }
    if(!preg_match("#\d{11}#", $tel)){
        $error[]="Invalid Phone no.";
    }
    if(count($error)==0){
        $pass=substr(sha1(md5($pass1)), 3, 10);
        $save=$conn->query("INSERT INTO admin SET name='$username', pass='$pass', tel='$tel', secret_key=$secret_key") or die( mysqli_error($conn));
        $_SESSION['who']=$username;
        header("location: $domain");
    } else {
        foreach($error as $error){
            $err.="<font color='red'><b>$error</b></font><br>";
        }
    }
}

?>
<h3 style="text-align: center">REGISTER AS ADMINISTRATOR</h3>
<br><br>
<div class="passwordEnter">
    <form method="post" action="">
        <?=$err?>
        Username:<br>
        <input type="text" name="name"><br><br>
        Password:<br>
        <input type="password" name="p1"><br><br>
        Verify Password:<br>
        <input type="password" name="p2"><br><br>
        <?php if($countU>0) { ?>
        Secret Key:<br>
        <input type="password" name="sc"><br><br>
        <?php } ?>
        Phone No.:<br>
        <input type="text" name="ph"><br><br>
        <input type="submit" name="reg" value="Log in">
    </form>
</div>