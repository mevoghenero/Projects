<?php
/* IMPORTANT FILES */
include "modules.php";

$pageTitle="Sucessvilla.com.ng Examination Expo Panel";

include "content.php";

//admin sign up
    $err="";
    if(isset($_POST['reg'])){
        $username=$_POST['name'];
        $password=$_POST['p1'];
        if(!$username || !$password){
            $err="Please enter username / password";
        }
        else {
            $pass=sha1($password);
            $q=$conn->query("SELECT * FROM admin WHERE name='$username' AND pass='$pass'") or die(mysqli_error($conn));
            if(mysqli_num_rows($q)>0){
                $_SESSION['who']=$username;
                header("location:$domain/admin-p.php");
                exit;
            }
            else {
                $err="Incorrect username/password";
            }
        }
    }

?>

<h3 style="text-align: center">ADMINISTRATOR LOGIN</h3>
<br><br>
<div class="passwordEnter">
    <div style="color:red; font-size:32px;"><?=$err?></div>
    <form method="post" action="">
        Username:<br>
        <input type="text" name="name"><br><br>
        Password:<br>
        <input type="password" name="p1"><br><br>
        <input type="submit" name="reg" value="Log in">
    </form>
</div>

<?php include "footer.php"; ?>