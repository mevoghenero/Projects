<?php
/* IMPORTANT FILES */
include "modules.php";
if(!isloggedin()){
    header("location:$domain/index.php");
    exit;
}

include "content.php";
$err="";
if(isset($_POST['subp'])){
    $title=$_POST['exsub'];
    $content=$_POST['post'];
    $time=time();
    if($title and $content){
        $q=$conn->query("INSERT INTO updates SET topic='$title', content='$content', postdate='$time'") or die($db->error);
        $err="Update added";
    } else {
        $err="An error occured";
    }
}
?>
<h1>Post new update</h1>
<div class="itemContainer">
        <div style="color:red; font-size:32px;"><?=$err?></div>

    <form method="post" action="">
        Title<br>
        <input type="text" name="exsub"><br><br>
        Content:<br>
        <textarea name="post" cols="30" rows="60" height="100" id="editor"></textarea><br><br>
        <input type="submit" name="subp" value="Post">
    </form>
</div>

<script>
    ClassicEditor
        .create( document.querySelector( '#editor' ) )
        .catch( error => {
            console.error( error );
        } );
  </script>