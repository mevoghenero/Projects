           <p><center><div style='background-color:#d6eaf8;padding:2px;color:black;border-radius: 17px;border:2px dashed black;height:40px:font-size:18px;'><marquee behavior='alternate' scrolldelay='200'><font color='red'>For Any Enquiry, Please Do Not Call US. Whatsapp Or Text Only: 07067172511</font> (We Reply Text Faster)</marquee></div></center></p>

<div class="footer">(c) Examvilla.Com.Ng<br>Powered By <a href="https://excellentloaded.com"><font color="red">Legendary</font></a></div>
        </body>
    </html>
<!-- </dOctype>