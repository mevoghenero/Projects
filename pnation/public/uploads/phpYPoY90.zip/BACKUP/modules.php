<?php
@session_start();
@ob_start();
$dbhost="localhost";
$dbuser="successv_legendary";
$dbpass="Excellentloaded1";
$dbtable="successv_success";


$conn=mysqli_connect($dbhost, $dbuser, $dbpass, $dbtable) or die(mysqli_error($conn));

function filter($content){
    global $conn;
    return $conn->real_escape_string($content);
}

if(get_magic_quotes_gpc()){
    $_GET=array_map("stripslashes", $_GET);
    $_POST=array_map("stripslashes", $_POST);
    $_COOKIE=array_map("stripslashes", $_COOKIE);
}


    $_GET=array_map("filter", $_GET);
    $_POST=array_map("filter", $_POST);
    $_COOKIE=array_map("filter", $_COOKIE);

    
//Domain
$domain="http://";
$domain.=$_SERVER['HTTP_HOST'];
$Ptitle="Exampasss Examination Expo panel";    
    
//Function
function enc($p){
    $d=substr(sha1(md5($p)), 3, 10);
    return $d;
}
function isloggedin(){
    if(isset($_SESSION['who']))
    return true;
}
if(isloggedin()){
    if(@$_GET['logout']==1){
    session_destroy();
    header("location:$domain?logout=1");
    exit;
}
}
    $who=@$_SESSION['who'];

function bb_code($str){
    $str=htmlspecialchars($str);
    $str=preg_replace("#\[img\](.*?)\[\/img\]#is", "<a href=\"$1\"><img src=\"$1\"></a>", $str);
    $str=preg_replace("#\[b\](.*?)\[\/b\]#is", "<b>$1</b>", $str);
    $str=preg_replace("#\[u\](.*?)\[\/u\]#is", "<u>$1</u>", $str);
    $str=preg_replace("#\[strike\](.*?)\[\/strike\]#is", "<strike>$1</strike>", $str);
    $str=preg_replace("#\[i\](.*?)\[\/i\]#is", "<i>$1</i>", $str);
    $str=preg_replace("#\[url=(.*?)\](.*?)\[\/url\]#is", "<a href=\"$1\">$2</a>", $str);
    $str=preg_replace("#\[color=(.*?)\](.*?)\[\/color\]#is", "<font color=\"$1\">$2</font>", $str);
    $str=preg_replace("#\[quote\](.*?)\[\/quote\]#is", "<div class=\"quote\">$1</div>", $str);
    $str=preg_replace("#\[center\](.*?)\[\/center\]#is", "<div align=\"center\">$1</div>", $str);
    $str=preg_replace("#\[left\](.*?)\[\/left\]#is", "<div align=\"left\">$1</div>", $str);
    $str=preg_replace("#\[right\](.*?)\[\/right\]#is", "<div align=\"right\">$1</div>", $str);
    $str=preg_replace("#\[big\](.*?)\[\/big\]#is", "<span style=\"font-size:32px\">$1</span>", $str);
    $str=preg_replace("#\[br\]#is", "<br>", $str);
    return nl2br($str);
}
?>