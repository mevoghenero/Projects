<?php
/* IMPORTANT FILES */
include "modules.php";
if(!isloggedin()){
    header("location:$domain/index.php");
    exit;
}
$pageTitle="Sucessvilla.com.ng Examination Expo Panel";

include "content.php";
$err="";
if(isset($_POST['subp'])){
    $subject=$_POST['exsub'];
    $pin=$_POST['exppin'];
    $post=$_POST['post'];
    $time=time();
    if($pin and $subject and $post){
        $pin=$pin;
        $save=$conn->query("INSERT INTO exam SET pass='$pin', subj='$subject'") or die (mysqli_error($conn));
        $id=mysqli_insert_id($conn);
        $doThis=$conn->query("INSERT INTO examp SET examid=$id, poster='$who', post='$post', timedd=$time") or die(mysqli_error($conn));
        header("location:$domain/page.php?id=$id");
    }
    else {
        $err="Seems You Missed something, Pls try again.";
    }
}
?>

<div class="space">
    5 Latest Exams - <a href="exams.php">All exams</a> - <a href="postupd.php"><span style="color:orange"><b>Post new update</b></span></a> &middot; <a href="upds.php">View All Updates</a> || <a href="logout.php">log out</a>
</div>

<?php

$q=$conn->query("SELECT * FROM exam ORDER BY id DESC LIMIT 5") or die(mysqli_error($conn));
if(mysqli_num_rows($q)==0){
    echo "NO EXAMS CREATED";
}
else {
    while($ftt=mysqli_fetch_object($q)){
        $idx=$ftt->id;
        $subjectx=$ftt->subj;
        $xpin=$ftt->pass;
        echo "<div class='itemContainer' style='text-align:left'>$idx. <a href='$domain/page.php?id=$idx'><font color='green'><b>$subjectx</b></font></a> -- PIN: <font color='red'><b>$xpin</b></font></div>";
    }
}
    $countUx=$conn->query("SELECT * FROM admin LIMIT 1");
    $countU=mysqli_num_rows($countUx);

if($countU==0){
        $secret_key=rand(1111,9999);
    } else {
        $ft=mysqli_fetch_object($countUx);
        $osc=$ft->secret_key;
    }
?>
<br><br>
<div class="space">
    SECRET KEY.
</div>
<div class="itemContainer">
    <b>NOTE:</b> Give the secret key only to the person you want to register as admin. Your secret key is <b style="color:crimson"><?=$osc?></b>
</div>
<br><br>
<div class="space">
    SET PASSWORD
</div>
<div class="itemContainer">
        <div style="color:red; font-size:32px;"><?=$err?></div>

    <form method="post" action="">
        Exam subject:<br>
        <input type="text" name="exsub"><br><br>
        Enter new exam pin:<br>
        <input type="text" name="exppin"><br><br>
        Content:<br>
        <textarea name="post" cols="30" rows="5"></textarea><br><br>
        <input type="submit" name="subp" value="Set Exam">
    </form>
</div>

<?php include "footer.php";?>