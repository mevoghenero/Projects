<?php
/* IMPORTANT FILES */
include "modules.php";

$pageTitle=$Ptitle;

include "content.php";

$qu=$_GET['q'];
if(!$qu){
    header("location:index.php");
}
?>
        <div class="itms">
            SCROLL DOWN FOR WAEC, NECO AND NABTEB DETAILS
        </div>

        <div class="space" style="margin:15px;">
            <b>
                Search results for '<?=$qu?>'
            </b>
        </div>

<?php
    #load updates
    $page_="";
    $q=$conn->query("SELECT * FROM updates WHERE topic LIKE '%$qu%' ORDER BY id DESC LIMIT 10") or die($conn->error);
    if($q->num_rows==0){
        $page_="No updates yet";
    } else {
        while($load=$q->fetch_object()){
            $uid=$load->id;
            $topic=$load->topic;
            $page_.='- <a href="view.php?id='.$uid.'">'.$topic.'</a><br>';
        }
    }
?>

<div class="updates">
    <?=$page_?>
</div>

<?php include "footer.php"; ?>