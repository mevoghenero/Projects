-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Apr 22, 2018 at 02:14 PM
-- Server version: 5.6.38
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `exampass_expo`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(1) UNSIGNED NOT NULL,
  `name` varchar(20) NOT NULL,
  `pass` varchar(225) NOT NULL,
  `secret_key` int(4) NOT NULL,
  `tel` varchar(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `pass`, `secret_key`, `tel`) VALUES
(0, 'Exampass', '3.141592653589793', 7916, '08105548666'),
(1, 'Exampass', '2ed716958c', 7916, '08142675572'),
(2, 'Admin', 'b53511aca43f3d70d2b29cd54b89fd1a', 6919, '08142675572');

-- --------------------------------------------------------

--
-- Table structure for table `exam`
--

CREATE TABLE `exam` (
  `id` int(1) UNSIGNED NOT NULL,
  `pass` varchar(225) NOT NULL,
  `subj` varchar(225) NOT NULL,
  `closed` int(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `examp`
--

CREATE TABLE `examp` (
  `id` int(11) UNSIGNED NOT NULL,
  `examid` int(11) UNSIGNED NOT NULL,
  `poster` varchar(225) NOT NULL,
  `post` text NOT NULL,
  `timedd` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `examp`
--

INSERT INTO `examp` (`id`, `examid`, `poster`, `post`, `timedd`) VALUES
(87, 79, 'ExpoNGâ„¢', '[color=green][b]HOW ARE YOU?[/b][/color]', 1523361165),
(92, 83, 'ExamLoaded', '[b][i]ExpoWeb Is The Best! Start Subscribing For Your Biology Obj And Answers Now! Biology Password Is #500 ... [/i]\r\n\r\nACCOUNT OBJ:\r\n1-10: DABDABABBC\r\n11-20: BCAADBBBAA\r\n21-30: ADCABCBDDC\r\n31-40: BACBDDACDB\r\n41-50: CCCBACCCAC\r\n\r\nVerified & Correct âœ…\r\n \r\n\r\n[img]http://k003.kiwi6.com/hotlink/dbluiu0n1x/IMG-20180419-WA0002.jpg[/img] \r\n\r\n[img]http://k003.kiwi6.com/hotlink/lij70drirv/IMG-20180419-WA0001.jpg[/img]\r\n\r\n1a)\r\n- It can result in a business exhausting the budget, leading to spending more than\r\nwhat is coming in.\r\n\r\n- Businesses may need to file for bankruptcy or shut their doors if they fail to keep adequate records from the\r\nbeginning.  \r\n\r\n-It can result in problems with suppliers, payroll, utilities, and other vital components to a running successful business.\r\n\r\n1b)\r\n- Relevance means an account information to make a difference in decision making\r\n- Comparability means an account information can be used to compare different entities\r\n- Consistency: information is consistently presented from year to year \r\n- Reliability means an account  information is verifiable, factual, and neutral\r\n\r\n1c\r\n- Accounting information is historical in nature \r\n- there is no information as to usefulness, size or quantity because accounting is expressed in monetary terms\r\n\r\n=============\r\n\r\n2a)\r\nDIRECT MATERIALS COST: This is the expenditure incurred on raw materials which can be traced to a particular production units..  E.g orange in fantasy making. \r\n\r\n*DIRECT LABOUR COST: This refers to the wages of employees who are directly engaged in the production process as e.g wages of machine operator.\r\n\r\n*FACTORY OVERHEAD\r\nThese relates to the expenditure incurred in running the factory which cannot be traced to a particular production units..\r\n\r\n\r\n2 b )\r\ni ) RAW MATERIALS: These are the materials or goods purchased by the manufacturer . Manufacturing process is applied on the raw material to produce desired finished goods.\r\nii) WORK - IN- PROGRESS (WIP): These are the partly processed raw materials lying on the production floor .\r\niii ) FINISHED GOODS: These are the final products after manufacturing process on raw materials. They are sold in the market . There are two kinds of manufacturing industries .\r\n\r\n================\r\n\r\n*3A* )\r\n\r\nWhere a big business with diverse trading activities is conducted under the same roof the same is usually divided into several departments and each department deals with a particular kind of goods or service. For example, a textile merchant may trade in cotton, woolen and jute fabrics. The overall performance for this type of business depends, however, on departmental efficiency.\r\n\r\n\r\n\r\n*3B* )\r\n(i) Compare the results among the different departments together with the previous results thereof,\r\n\r\n(ii) Formulate policy in order to extend or to develop the enterprise in the proper line; and\r\n\r\n================\r\n\r\n4a\r\n- employees\r\n- banks\r\n- government\r\n- creditors\r\n- analyst\r\n- owners\r\n\r\n=================\r\n\r\n(6a)\r\nTABULATE\r\nCash book Adjustment\r\nBal bld N 48,500\r\ninterest on investment N 2500\r\ncredit transfer N 3000\r\n54,000\r\nLeft Table\r\nBank Charges N 1000\r\nDishonured cheques N 2000\r\nbal cld N 51,000\r\n54,000\r\nTotal Bal bld N 51,000\r\n\r\n(6b)\r\nTABULATE\r\nBank Reconcilation statement at 31/ 12/ 2016\r\nbalance as per adjusted cash book N N 51,000\r\nadd unpresented cheques 8850\r\nadd back wrong credit 3500\r\n12,350 / 63,350\r\nless uncredited cheques ( 8450)\r\nbalance as per bank statement N 54,900\r\n\r\n\r\n==========\r\n\r\n(7a)\r\nStatement Of affairs as at 1 | 1 | 06\r\nTabulate\r\nRight Table\r\nCapital ( Opening ) N 30,000\r\nCreditors N 1 ,000\r\nInsurance N 2 ,000\r\nN 33,000\r\nLeft Table\r\nLand And Building N 15,000\r\nMotor Vechicle N 6 ,000\r\nStock N 4 ,000\r\nCash N 6 ,000\r\nDebtors N 2 ,000\r\nN 33,000\r\n\r\n(7b)\r\nTrading Profit and loss account for the year ended 31st december 2016\r\nTabulate\r\nRight Table\r\nopening stock N 4000\r\npurchases N 11,500\r\n15,500\r\nClosing Stock ( 2 ,000 )\r\nCost of goods sold 13500\r\ngross profit cld 17500\r\n31,000\r\nsalaries N 5000\r\nrent and rates N 4000\r\ninsurance N 5000\r\ndep on motor vechicle N 2000\r\nnet profit N 1500\r\n17500\r\nLeft Table\r\nSales N 31,000\r\n31,000\r\ngross profit b | d N 17,500\r\nN 17,500\r\n\r\n(7c)\r\nBalance Sheet as at 31| 12| 2006\r\nTabulate\r\nRight Tabule\r\nCapital N 30,000\r\nadd net profit N 1500\r\nN 31,500\r\ncurrent liability\r\ncreditor N 500\r\ninsurance Owning N 6000\r\nN 38,000\r\nTable Left\r\nFixed Assests\r\nLand and Building N 15,000\r\nmotor vehicle N 4000\r\n19,000\r\ncurrent assets\r\nstock N 2000\r\ndebtors N 3000\r\nCash N 14,000\r\nN 38,000\r\n\r\n\r\n==========\r\n\r\n \r\n(9)\r\nObihan trading profit and loss account\r\n\r\nSALES =  1,200,000\r\nLess return inward =              \r\n 15,000\r\n= 1,185,000\r\n\r\nLess cost of sales\r\nOpening stock = 3000,000\r\nAdd purchase 1,050,000\r\nLess return outward = 18,600\r\n\r\nNet purchase=1,031,400\r\nCost of goods available. =1,331,400\r\nLess closing stock=360,000\r\nCost of goods sold=971,400\r\nGROSS PROFIT=213600\r\n\r\n\r\nLESS OPERATIVE EXPENSIVE\r\nRates (18,000 +1,500) = 16,500\r\nRates ( 18,000 + 660) = 3,660\r\nSalaries (90,000 + 15,000) = 105,000\r\nBad Debits = 600\r\nInsurance = 93,000\r\nDepreciation: Furniture 9,000\r\nMachineries  = 18,000\r\nProvision for bad debit = 540\r\nNET LOSS 246,300\r\n                     32,700\r\n\r\n\r\n[color=red]NOTE:[/color] If You Gave Or Show Someone Your Password, The System Will Blocked You From Viewing ANSWERS, Keep Your Password Safe, It\'s For You Alone, Thanks[/b]', 1524115655),
(93, 84, 'ExamLoaded', '[b][i] Answers Updated! ExpoWeb Is A The Best \r\nTell Your Friends About Expoweb.com.ng âœ… [/i]\r\n\r\nBIOLOGY OBJ:\r\n1-10: BCDCDACDAB\r\n11-20: ADADCBACBC\r\n21-30: CABBDBAADC\r\n31-40: AABCCBCDAA\r\n41-50: AACBABDDAB\r\n \r\nVerified & Correct!\r\n\r\n\r\n1i) Sperm cell is the male reproductive cell that is expelled along with the seminal fluid or semen when a man ejaculates. In humans, spermatozoa determine the gender of the baby-to-be, which means that they can carry either the X or the Y chromosome.\r\n\r\nii)Palisade cells are found in the mesophyll of a leaf and their main function is the absorption of light so that photosynthesis can take place. The palisade mesophyll consists of chloroplasts with chlorophyll that absorb the light energy.\r\n\r\n1b) Draw Below Diagram\r\n\r\n[img]https://expoweb.com.ng/wp-content/uploads/2018/04/IMG-20180419-WA0146.jpg[/img]\r\n\r\n\r\n(1c) \r\nIN A TABULAR FORM MAMMALS AND AMPHIBIANS \r\n\r\nMAMMALS \r\n\r\n- Mammals give birth to their young ones alive. \r\n\r\n- Mammals produce amniotic eggs\r\n\r\n\r\nAMPHIBIANS\r\n\r\n- Amphibians lay eggs\r\n- Amphibians do not produce amniotic eggs\r\n\r\n(1d) \r\n\r\n- Use of condoms/pills\r\n- withdrawal \r\n\r\n============\r\n\r\n(2a)\r\ni) carbon dioxide\r\nii) Nitrogen\r\n\r\n(2b)\r\n(i) CO 2 is used by plants to photosynthesize carbohydrates .\r\nii) Nitrogen is a major component of chhlorophyll\r\n\r\n(2ci)\r\nVariegated leaf is a leaf that has green parts ( where the cells contain chlorophyll) and non green parts ( where there is no chlorophyll).\r\n\r\n(2cii)\r\nThe green parts\r\n\r\n(2ciii)\r\ni) The parts without chlorophyll do not photosynthesise\r\nii) the cells contain chlorophyll\r\n\r\n(2civ) Nitrogen \r\n\r\n(2d) \r\nHolozoic:\r\nHuman \r\n\r\nParasitic:\r\nTapeworm; Venus flytrap \r\n\r\nSymbiotic:\r\nLichen \r\n\r\nSaorophytic:\r\nRhizopus; mushroom; housefly. \r\n\r\nAutotropic: \r\nSpirogyra; waterleaf plant; elephant grass.\r\n\r\n\r\n=================\r\n\r\n\r\n3ai)\r\nrenewable resourceÂ is aÂ resourcewhich can be used repeatedly and replaced naturally.Â \r\n\r\n3aii)\r\nnonrenewable resource is a resource of economic value that cannot be readily replaced by natural means on a level equal to its consumption.Â \r\n\r\n3bi)\r\ni)oxygen\r\nii)fresh water\r\n\r\n3bii)\r\nI)oil\r\nii)natural gas\r\n\r\n3c)\r\ni)Regulated and Planned Cutting of Trees.\r\nii)Control over Forest Fire.\r\niii)Reforestation and Afforestation.\r\nv)Check over Forest Clearance for Agricultural and Habitation Purposes.\r\niv)Proper Utilisation of Forest and Forests Products.\r\n\r\n(3d)\r\n(i) Increases soil nutrients \r\n(ii) Improves soil structure. \r\n(iii) Does not corrupt the soil. \r\n(iv) Increases soil humus. \r\n\r\n(3e)\r\n(i)z AA\r\n(ii) AO\r\n(iii) BB\r\n(iv) BO\r\n\r\n===============================\r\n\r\n4a)\r\nÂ A gene is the basic physical and functional unit of heredity. Genes, which are made up of DNA, act as instructions to make molecules called proteins. In humans, genes vary in size from a few hundred DNA bases to more than 2 million bases.\r\n\r\n4aii) HYBRID\r\n\r\nIn biology, a hybrid, or crossbreed, is the result of combining the qualities of two organisms of different breeds, varieties, species or genera through sexual reproduction.\r\n\r\n4b) Draw The Diagram Below \r\n\r\n[img]https://expoweb.com.ng/wp-content/uploads/2018/04/IMG-20180419-WA0190.jpg[/img] \r\n\r\n4ci height of plant\r\nii size of various parts of the plant such as stems, leaves, flowers, fruits\r\niii color of parts of plants such as green, white and brown of leaves, stem and root\r\n\r\n==============\r\n\r\n6ai)\r\nChemosynthesis is the biological conversion of one or more carbon-containing molecules (usually carbon dioxide or methane) and nutrients into organic matter using the oxidation of inorganic compounds (e.g., hydrogen gas, hydrogen sulfide) or methane as a source of energy, rather than sunlight\r\n\r\n6aii)\r\ni)Bacteria \r\nii)methanogenic archaea\r\n\r\n6b)\r\nNitrogen â€” 78 percent.\r\nOxygen â€” 21 percent.\r\nArgon â€” 0.93 percent.\r\nCarbon dioxide â€” 0.04 percent.\r\n\r\n(6c)\r\n(i) - They are composed of relatively few species of plants\r\n(ii) - The salt level of the habitat is high\r\n(iii) - High flooding rate\r\n(iv) - extreme temperature and salinity fluctuations.\r\n\r\n(6cii)\r\nRoots of salt marsh plants help stabilize the sandy substrate and trap and hold nutrients and detritus that flow through with each tidal cycle. This detritus trap helps feed bacteria, algae, and invertebrates. These root tangles also provide critical refuge for small fish and other animals.\r\n\r\n6di) \r\n(i) Typhoid fever.\r\n(ii) Dysentery. \r\n(iii) Cholera. \r\n        \r\n(6dii) \r\n(i)Food poisoning \r\n(ii) Food spillage. \r\n(iii) Low market value of food. \r\n\r\n(6e) \r\nThe person need plenty of rest and diet rich in protein, fruits and vegetables and take plenty of water. \r\n\r\n(6f) \r\nIn a tabular form:\r\n \r\nUnder Tillage:\r\n(i) The soil is prepared. \r\n(ii) conserve soil nutrients. \r\n(iii) Good for farm products. \r\n\r\nUnder Bush burning:\r\n(i) Fire is used to remove plants. \r\n(ii) Destroys soil nutrients. \r\n(iii) A bad farm practice.\r\n\r\n\r\n More Loading.............\r\n\r\n\r\n[color=red]NOTE:[/color] If You Gave Or Show Someone Your Password, The System Will Blocked You From Viewing ANSWERS, Keep Your Password Safe, It\'s For You Alone, Thanks[/b]', 1524115741),
(91, 82, 'ExamLoaded', '[b][i][/i]\r\n\r\n\r\nMaths Obj\r\n1-10: ACBCDDCBAA\r\n11-20: CDCABCCCAC\r\n21-30: DADBABCDAD\r\n31-40: BADADBCACB\r\n41-50: ADDDBDADCA\r\n\r\n1) \r\nOn February 28th 2012 \r\nValue = (100-30/100) * #900,00.00\r\n= 70/100 * #900,00\r\n= #630,000.00\r\n\r\nOn february 28th 2013\r\nValue = (100-22/1000 * #630,00\r\n= 78/100 8 #630,000\r\n= #491,400\r\n\r\nOn february 28th 2014\r\nValue = 78/100 8 #491,400\r\n=383,292\r\n\r\nOn february 28th 2015\r\nValue = 78/100 * #383,292\r\n= #298,967.76\r\n\r\n========\r\n\r\n\r\nNO2)\r\nGiven that y = 2pxË†Â² â€“ pÂ² x â€“ 14\r\nAT (3, 10)\r\n10 = 2p(3)Â²Â  â€“ pÂ² (3) â€“ 14\r\n10 = 18p â€“ 3pÂ²Â  â€“ 14\r\n3pÂ²Â  â€“ 18p + 24 = 0\r\npÂ²Â  â€“ 6p + 8 = 0\r\n\r\nUsing factor method,\r\n\r\npÂ²Â  â€“ 2p -4p + 8 = 0\r\np(p-2) â€“ 4(p-2) = 0\r\n(p-4)(p-2) = 0\r\np-4 = 0 or p-4 = 0\r\np= 4 or p =2\r\n\r\n===========\r\n\r\n2b) The lines must be solved simultenously\r\n\r\n3y â€“ 2x = 21 â€”â€”- (1)\r\n\r\n4y + 5x = 5 â€”â€”-(2)\r\n\r\nusing elimination method,\r\n\r\n(4)Â  3y â€“ 2x = 21\r\n\r\n(30 4y + 5x = 5\r\n\r\n12y â€“ 8y = 84 â€”â€”â€” (3)\r\n\r\n12y + 15x = 15 â€”â€”-(4)\r\n\r\nequ (4) minus equ(3)\r\n\r\n23x = -69\r\n\r\nx = -69/23\r\n\r\nx = -3\r\n\r\nPut this into equation (1)\r\n\r\n3y -2(-3) = 21\r\n\r\n3y = 6 = 21\r\n\r\n3y = 21 -6\r\n\r\n3y = 15\r\n\r\ny =15/3\r\n\r\ny = 5\r\n\r\ncoordinates of Q is (-3, 5)\r\n\r\n============\r\n\r\n(3a)\r\nThe diagonal = 10.2m and 9.3cm\r\nUsing Pythagoras theory \r\nAcÂ² = 10.2Â² + 9-3Â²\r\nAcÂ² = 104.04 + 86.49\r\nAcÂ² = 190.53\r\nAcÂ² = âˆš190.53\r\nAcÂ² = 13.80\r\n\r\n(3b)\r\nDRAW THE DIAGRAM\r\nUsing Pythagoras theory \r\n5Â² = 3Â² + xÂ²\r\nxÂ² = 5Â² - 3Â²\r\nXÂ²= 25 - 9\r\nXÂ² = âˆš16\r\nX= 4cm\r\nCosX = adjacent/hyp\r\n= 4/5\r\nTan X = opp/adj. = 3/4\r\n5cos x - 4tan x\r\n5(4/5)- 4(3/4)\r\n20/5 - 12/4\r\n4-3= 1\r\n\r\n============\r\n\r\n4 ai)\r\nsum of angle in a D = 180 degree\r\nxdegree + 90degree + 180 degree - ( 3 x+ 15)=180 degree\r\nxdegree + 90degree + 180 degree - 3 x+ 15= 180 degree\r\n- 2 x= 180 degree - 255\r\n+ 2 x/ 2 = + 75/ 2\r\nx= 37. 5\r\n4 aii )\r\n<RsQ = 180 - ( 3 x+ 15)\r\n<RsQ = 180 - ( 3 * 37. 5 + 15)\r\n= 180 - ( 112 . 5 + 15)\r\n= 180 - 127 . 5\r\n<RsQ = 52. 5 degree\r\n4 b )\r\n2 N 4 seven = 15Nnine\r\n2 * 7 ^ 2 + N * 7 ^ 1 + 4 * 7 degree = 1 * 9 ^ 2 + 5 * 9 ^ 1 + N * 9 degree\r\n9 * 49+ N * 7 + 4 * 1 = 1 * 81+ 5 * 9 + N * 1\r\n98+ 7 N + 4 = 81+ 45+ N\r\n7 N + 102 = 126 + N\r\n7 N - N = 126 - 102\r\n6 N / 6 = 24/ 6\r\nN = 4\r\n\r\n==============\r\n\r\n(5a)\r\nm+n+s+p+q/5=12\r\nm+n+s+p+q=60......(1)\r\nNow;\r\n(m+4)+(n-3)+(5+6)+p-2)+(q+8)/5\r\n=(m+n+s+p+q)+(4-3+3+6-2+8)/5\r\n=60+13/5\r\n=73/5\r\n=14.6\r\n\r\n(5b)\r\n75% of 500 = 375 people\r\nNumber of people above 65 years = 500-375\r\n=125\r\n\r\n25% of 500 = 125\r\nNumber of people below 15 years = 125\r\nNumber between 15 years and 65 years\r\n=500-(125+125)\r\n=500-250\r\n=250 people\r\n===========  \r\n\r\n(6a)\r\nDraw the Venn diagram\r\nLet the number of cars with faults in brakes only be x\r\n(6b) Number that passed = 60% Ã— 240 = 144\r\nNumber that failed =\r\n240 - 144 = 96\r\nTherefore; 28+2x+x+14+6+6-x+8 = 96\r\n2x + 62 = 96\r\n2x = 96 - 62\r\n2x = 34\r\nX = 34/2\r\nX = 17\r\n(i) faulty brakes cars = 8+6+x+6-x\r\n= 8+6+6\r\n=20\r\n(ii) only one fault = 28+x+2x\r\n=28+3x\r\n=28+3(19)\r\n=28+51\r\n= 79\r\n\r\n==============\r\n\r\n(7a)\r\n(y-y1)/(x-x1)=(y2-y1)/(x2-x1)\r\n(y-5)/(x-2)=(-7-5)/(-4-2)\r\n(y-5)/(x-2)=-12/-6\r\n(y-5)/(x-2)=2\r\nCross multiply\r\ny-5=2(x-2)\r\ny-5=2x-4\r\n2x-y-4+5=0\r\n2x-y+1=0\r\n\r\n(7bi)\r\nDRAW THE DIAGRAM\r\n\r\n(7bii)\r\n(I)\r\np^2=q+r^2-2qrcosP\r\np^2=8^2+5^2-2*8*5*cos90\r\np^2=64+25-0\r\np^2=89\r\np=sqroot(89)\r\np=9.4339km\r\ntherefore |QR|=9.43km(3 sf)\r\n\r\n(II)\r\nq/sinQ=p/sinP\r\n8/sinQ=9.4339/sin90\r\nsinQ=(8*sin90/9.4339\r\nsinq=(8*1)/9.4339 =0.8480\r\nQ=sin^1(0.8480)=57.99 degrees\r\nbut Q=30+ A\r\nA=Q-30\r\n=57.99-30 \r\nA=27.99 degrees\r\nThe bearing of R from Q\r\n=180-A\r\n180-27.99\r\n=155.01\r\n=>152 degrees\r\n============\r\n\r\n(8a) \r\nCost price for Lami= #300.00\r\n  Profit made by lami = x%\r\nIe selling price for lami=(100+x/100)Ã—#300\r\n=#3(100+x)\r\n=#(300+3x)\r\n\r\nBola\'s cost price = #3(100+x)\r\nProfit made by bola =x%\r\nSelling price for bola =(100+x/100)Ã—#3(100+x)\r\n=#3/100(100+x)Â²\r\n\r\nJames cost price =#3/100(100+x)Â²=300+(6x+3/4)\r\nexpanding;\r\n3/100(10000+200+xÂ²) = 300+3/4+6x\r\n3(10000+200x+xÂ²)=30000+75+600x\r\n30000+600x+3xÂ²=30000+75+600x\r\n3xÂ²=75\r\nXÂ² = 75/3\r\nXÂ² = 25\r\nX = square root 25\r\nX = 5\r\n\r\n(8b) \r\n3x-2<10+x<2+5x\r\n3x-2<10+x & 10+x<2+5x\r\n3x-x<10+2 & 10-2<5x-x\r\n2x<12              8<4x\r\nX<12/2            4x>8\r\nX<6                   x>8/4\r\n                          X>2\r\n\r\nAlso; 3x-2<2+5x\r\n          -4<2x\r\n          2x > -4\r\n          X > -2\r\nTherefore; Range is -2<X<6\r\n\r\n============\r\n\r\nNO9) Using cosine rule,\r\n\r\n|TQ|Ë†Â² = 4Ë†Â² + 6 Ë†Â² â€“ 2(4)(6) cos30Â°\r\n\r\n|TQ|Ë†Â² = 16 + 36 â€“ 48(0.8660)\r\n\r\n|TQ|Ë†Â² = 52 â€“ 41.568\r\n\r\n|TQ|Ë†Â² = 10.432\r\n\r\nTQ = âˆš10.432\r\n\r\nTQ = 3.23CM\r\n\r\nFrom similar triangles;\r\n\r\n|PT|/|TQ| = |PS|/|SR|\r\n\r\n4/3.23 = 10/|SR|\r\n\r\n4|SR| = 32.3\r\n\r\n|SR| = 32.3/4\r\n\r\n|SR| = 8CM (nearest whole number)\r\n\r\n============\r\n\r\n(10a) Using Pythagoras theorem from SPQ\r\n|SQ|^2 = 12^2 + 5^2\r\n= 144+25\r\n=169\r\nSQ= sqroot of 169\r\n= 13cm\r\nSin tita= 5/13 = 0.3846\r\nTita= Sin^-1(0.3846)\r\n= 22.6degrees\r\nFrom PRQ\r\nSin tita= |PR|/12\r\nSin 22.6 = PR/12\r\nSin 22.6= PR/12\r\nPR= 12xsin 22.6\r\nPR= 12x0.3843\r\nPR= 4.61cm\r\n(10bii)Let the height at which m touches the wall= y\r\nCos x^degrees= 8/10= 0.8\r\nx^degrees= Cos^-1(0.8)\r\n= 36.87degrees\r\nSin x^degrees = y/12\r\nSin 36.87= y/12\r\ny= 12xsin36.87\r\ny= 12x0.60000\r\ny= 7.2m\r\n\r\n================\r\n\r\n[color=red]NOTE:[/color] If You Gave Or Show Someone Your Password, The System Will Blocked You From Viewing ANSWERS, Keep Your Password Safe, It\'s For You Alone,Thanks[/b]', 1524008782),
(95, 85, 'ExamLoaded', '[b]Tell Your Friends About Expoweb.com.ng âœ… \r\nWe Are Always The Best And Continue To Be The Best! \r\n\r\n\r\n[u]Answers Updated![/u]\r\n\r\nPHYSICS OBJ\r\n\r\n1-10 CAABACBADB\r\n11-20 ACCCDABDCC\r\n21-30 DBADCABCAB\r\n31-40 CCBBCCBABD\r\n41-50 BDCDBABBDC\r\n\r\n===================================\r\n\r\n1a)\r\nStrain can be defined as the ratio of extension per unit length\r\nStrain=extension/length\r\n\r\n1b)\r\nStrain=extension/length\r\nLet original length=L\r\nFinal length=2L\r\nExtension=2L-L=L\r\nStrain=L/L=1\r\n\r\n===================================\r\n\r\n (2)\r\nMaterial used for making optical fibers \r\n(i) Silicon Dioxide\r\n(ii) Silica Powder \r\n(iii) Germanium Tetrachloride \r\n\r\n===================================\r\n\r\n3)\r\n-Diamagnetic material\r\n-Paramagnetic material\r\n-Ferromagnetic material\r\n\r\n===================================\r\n\r\n(4a)\r\nAn intrinsic semiconductor is an undoped semiconductor that is a pure semiconductor without any significant dopant\r\nspecies present.\r\n\r\n(4b)\r\nThe P Type semiconductor is a type of semiconductor that carries a positive charge, while the N type semiconductor carries a negative charge.\r\n\r\n===================================\r\n\r\n5)\r\nRange = uÂ²Sin2tita/g\r\nAt maximum range \r\nSin2tita = 1\r\n2tita =sin^-1(1)\r\n2tita = 90dgrees \r\nTita = 90/2 = 45degree\r\n\r\nMaximum height reached = uÂ²sinÂ²tita/2g\r\n=uÂ²(sin45)Â²/2g\r\n=200Â²(sin45)Â²/2(10)\r\n=40000(1/âˆš2)2/20\r\n=40000(1/2)/20\r\n=20000/20\r\n=1000metres.\r\n\r\n===================================\r\n\r\n7\r\n(a). LASER stands for Light Amplification by Stimulated Emission of Radiation. \r\n  \r\n (b). A laser is a device that emits a beam of coherent light through an optical amplification process.\r\n\r\n===================================\r\n\r\n8)\r\n[img]https://expoweb.com.ng/wp-content/uploads/2018/04/IMG-20180420-WA0090.jpg [/img]\r\n\r\n===================================\r\n\r\n(9ai)\r\ni) Nature of surface\r\nii) medium of transmission\r\n\r\n(9aii)\r\ni) state or phase of the substance ( i : e solid ,or gas)\r\nii) temperature of the meduim\r\n\r\n(9b)\r\ni) temperature\r\nii) specific heat capacity of the body\r\n\r\n(9c)\r\nthe statement means that the amount of heat energy required to change 1 kg of liquid mercury to gaseous mecury without change in temperature is 2 . 72* 10^ 5 jkg^ - 1\r\n\r\n(9di)\r\nQ= MCDSin\r\nV ^ 2 / R t = MCDsin\r\n( 220 )^ 2 * 4 * 60/ 35= M * 4200* ( 100 - 28)\r\n331885. 7 = 302400m\r\nm = 331885. 7 / 302400 = 1 . 098 kg\r\n\r\n(9dii)\r\nV ^ 2 / R t = MLv\r\n( 220 )^ 2 * 5 * 60/ 35= 0 . 3 * Lv\r\n414857. 14= 0 . 3 Lv\r\nLv = 414857. 14/ 0 . 3\r\nLv = 1382857 . 13JKg ^ - 1\r\n\r\n===================================\r\n\r\n(10a)\r\nDiffraction is the ability of waves to bend around obstacles in their path\r\n\r\n(10bi)\r\nCritical angle is the highest angle of incidence in a denser medium when angle of refraction in the less dense mediumis 90 degrees\r\n\r\n(10bii)\r\nCritical angle=90-44=46degrees\r\nThe refractive index of the glass is obtained as follows\r\nThe refractive index(n)=sini/sinr=sin46/sin90=0.7193/1\r\n=0.7193\r\n\r\n(10ci)\r\nfo=200Hz\r\nf1=3v/4l =>closed pipe\r\nf1=v/l=>open pipe\r\nbut 3fo=f1=>closed pipe\r\n3*200=f1=>f1=600Hz\r\nAlso f1=2fo=>open pipe\r\n2fo=600\r\nfo=600/2=300Hz\r\n\r\n(10cii)\r\nv=330m/s\r\nL=?\r\nfo=200Hz\r\nfo=v/4l\r\n=>200=330/4l\r\n800l=330\r\nl=330/800\r\nl=0.4124m\r\n\r\n(10ciii)\r\nfo=v/2l\r\nfo=300Hz\r\nv=330m/s\r\n300=330/2l\r\nl=330/600\r\nl=0.55m\r\n\r\n===================================\r\n\r\n(11ai)\r\nReactance is the opposition offered to the passage of an alternating current by either the inductor OR the capacitor or both. \r\n\r\n(11aii)\r\nImpedance is the overall opposition of a mixed circuit To the flow of an alternating current in a ressistor OR capacitor. \r\n\r\n(11bi)\r\nE.m.f is induced in an a.c generator so as to create more magnetic flux which generates an induced current. \r\n\r\n(11bii) \r\nThe carbon brushes makes contact with the springs so that the amature rotates through it. Induced current will be produced. It  also used to alternate the direction of the current produced. \r\n\r\n(11biii) \r\nThe law states that if the first three fingers of one\'s right hand are held at right angles to each other with the fore finger in the direction of the the field and the third in the direction of the motion, the middle finger points in the direction of the induced current. \r\n\r\n(11biv) \r\n-Increasing the no of coils. \r\n- The presence of soft iron core inside the coil. \r\n\r\n(11c) \r\nEnergy E = power Ã— time\r\nE = pt; where p=6w, t=60mins\r\nE= 6 Ã—5 Ã—60\r\n= 180J\r\n\r\n===================================\r\n\r\n(12a) This is defined as the amount of energy that must be supplied to a nucleus to completely separate it\'s nuclear particles (nucleons)\r\n\r\n(12b) \r\n(i) They have short wavelength and high frequency. \r\n(ii) They are highly penetrating. \r\n(iii) They travel in straight lines. \r\n(iv) They don\'t require material medium for their propagation.\r\n\r\n(12c) \r\n-It is used in production of electricity. \r\n-It is used to study and detect charges in genetic engineering. \r\n-It is used in agriculture. \r\n-It is used in treatment of cancer. \r\n\r\n(12di)\r\nE = hf-hfo\r\nbut f = v/landa\r\nE= v/landa.h - wo\r\nWhere wo = hfo = work function \r\nf= frequency \r\nlanda = wavelength \r\nHence \r\nhf = hfo - E\r\nf = hfo - E/h\r\nf = wo - E/h\r\nRecall; that v = f landa\r\nTherefore f = v/landa = 3Ã—10^8/4.5Ã—10-7\r\n=3/4.5 Ã— 10^8+7\r\n=6.6Ã—10^14Hz\r\nf = 6.6Ã—10^14Hz\r\n\r\n(12dii) \r\nE = hf\r\n=6.6Ã—10^-34 Ã— 6.6Ã—10^14Hz\r\n=43.56Ã—10^-20J\r\n\r\n(12diii) \r\nEnergy of the photoelectron E = hf - vo\r\n=Energy of incident electron - work function \r\n=4.356Ã—10^-19J - 3.0Ã—10^-19J\r\n=1.356Ã—10^-19J\r\n\r\n===================================\r\n===================================\r\n===================================\r\n===================================\r\n===================================\r\n\r\n\r\n[color=red]NOTE:[/color] If You Gave Or Show Someone Your Password, The System Will Blocked You From Viewing ANSWERS, Keep Your Password Safe, It\'s For You Alone, Thanks[/b]', 1524202436),
(96, 86, 'ExamLoaded', '[b][i] Answers Loading.... [/i]\r\n\r\n\r\n(1a and 1b)\r\nYOU HAVE TO VIEW THIS NUMBER WITH A BROWSER:\r\nwww.tinyurl.com/cbkgeogeo\r\n\r\n(1c) \r\nGradient = vertical height/horizontal height. \r\n= 1100 - 850/12.4Ã—50,000\r\n=250ft\r\n=250/6.2km\r\n=40.32ft/km\r\n\r\n(1d)\r\n(i) It is the major drainage of the mapped area. \r\n(ii) It has a trellis drainage pattern.\r\n\r\n[img]https://expoweb.com.ng/wp-content/uploads/2018/04/IMG-20180420-WA0145.jpg[/img]\r\n\r\n\r\n2c)\r\n-If well constructed it shows distribution and comparative densities\r\n\r\n-It is easier to show variation in distribution of wide variety of commodities if it is presented using different colours.\r\n\r\n==========================\r\n\r\n3)\r\n\r\n[img] https://i.imgur.com/1gfs8iT_d.jpg?maxwidth=640&shape=thumb&fidelity=medium[/img]\r\n\r\n\r\n============================\r\n\r\n[img] https://expoweb.com.ng/wp-content/uploads/2018/04/IMG-20180420-WA0147.jpg[/img] \r\n\r\n4ai)\r\ni)caves\r\nii)sinkholes\r\niii)skyline landscapes\r\n\r\n4aii)\r\nDrawing\r\n\r\n4b)\r\ni)Limestone are all used to neutralise excess acidity of soil in agriculture practice.Â \r\nii)Limestone is used as a building material.Â \r\niii)It is used in industries to purify iron in blast furnaces.Â \r\niv)It used in Glass making.\r\n\r\n================================\r\n\r\n5a)\r\n[img] https://expoweb.com.ng/wp-content/uploads/2018/04/IMG-20180420-WA0157.jpg[/img] \r\n\r\n5b)\r\ni)A great circle is the shortest path between two points along the surface of a sphere. \r\nii)great circle is the intersection of the surface with a plane passing through the center of the planet. \r\niii)They cross successive meridians at different angles.\r\n\r\n5c)\r\ni)Great circle are of importance to navigation and aviation.\r\nii)The shortest route between any two places is along the arc of the great circle which passes through them.\r\niii)Ships crossing the vast oceans and aircrafts follow the Great circle route in order to save fuel and time.\r\n\r\n=========================================\r\n\r\n\r\n7a) [img] https://expoweb.com.ng/wp-content/uploads/2018/04/IMG-20180420-WA0142.jpg[/img]\r\n\r\n=================================\r\n\r\n(8a)\r\ni)Encroachment : More migration lead to less availability of land which lead to higher economic value of land.Â \r\n\r\nii)Pollution: Explosive increase in the urban population without corresponding expansion of civic facilities such as lack of adequate infrastructure for the disposal of waste results in waste clogging the natural channels and storm water drains.\r\n\r\niii)Illegal mining activities: Illegal mining for building material such as sand and quartzite both on the catchment and on the bed of the lake have extremely damaging impact on the water body.Â \r\n\r\niv)Interference in drainage system: Drainage congestion caused by badly planned construction of bridges , roads , railway tracts, hampers the flow of water and the result is flood.\r\n\r\n(8b)\r\n- Flooding leads to loss of human lifeÂ \r\n- Flooding leads to damage to property\r\n- It leads to destruction of crops\r\n\r\n(8c)\r\n(i) Improving Drainage\r\nImproving water drainage helps control floods by facilitating easy flow of excess water, especially in urban areas during flash floods.\r\n\r\n(ii) Building Dikes and Levees Dikes and levees are flood- control structures built to fight river flooding and water surges.\r\n\r\n(iii) Building Canals\r\nCanals are artificial water channels that can be crucial to flood prevention . Canals facilitate control of water levels passing through , and form linear reservoirs and water locks \r\n\r\n(iv) Harvesting Rain Water\r\nHarvesting rainwater involves collecting and storing rainwater and can not only prevent floods , it can also curb urban water scarcity\r\n\r\n==================================\r\n\r\n\r\n[color=red]NOTE:[/color] If You Gave Or Show Someone Your Password, The System Will Blocked You From Viewing ANSWERS, Keep Your Password Safe, It\'s For You Alone, Thanks[/b]', 1524202548);

-- --------------------------------------------------------

--
-- Table structure for table `updates`
--

CREATE TABLE `updates` (
  `id` int(11) NOT NULL,
  `topic` varchar(300) NOT NULL,
  `content` text NOT NULL,
  `postdate` int(11) NOT NULL,
  `hits` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `exam`
--
ALTER TABLE `exam`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `examp`
--
ALTER TABLE `examp`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `updates`
--
ALTER TABLE `updates`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(1) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=81;

--
-- AUTO_INCREMENT for table `exam`
--
ALTER TABLE `exam`
  MODIFY `id` int(1) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=87;

--
-- AUTO_INCREMENT for table `examp`
--
ALTER TABLE `examp`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=97;

--
-- AUTO_INCREMENT for table `updates`
--
ALTER TABLE `updates`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
