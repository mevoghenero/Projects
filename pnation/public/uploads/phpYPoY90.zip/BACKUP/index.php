<?php
/* IMPORTANT FILES */
include "modules.php";

$pageTitle=$Ptitle;

include "content.php";

if(isloggedin()){
    header("location:admin-p.php");
}
?>
<div class="itms">
    <p style="background-color: gold; "><i class="fas fa-hand-point-right"></i> 2019 WAEC ANSWERS</p>
To Subscribe, For Each Subject is N400 while English and Maths is N1000 each. Send MTN Card to <b>07067172511</b>. Please don't call this number, only text us and we are going to reply within 10mins
</div>
        <!-- QUICK LINK HERE -->
        <div class="col-md-12 col-xs-12">
<div class="well">
<b><u style="background-color: gold;"><i class="fas fa-hand-point-right"></i> Quick Links!</u></b> 
<p><b>WITH QUALITY ASSURANCE OF MAKING YOUR PAPERS IN ONE SITTING</b><br><i>How To Pass And Make A/B/C's in Your EXAMS [May/June Or Nov/Dec]</i></p><hr>
<p>For Jamb <a href="xjamb.php"><b>Click Here</b></a></p>
<hr>
<p>For Waec <a href="xwaec.php"><b>Click Here</b></a> <img width="15" height="15" src="public/fire.png" alt="" /></p>
<hr>
<p>For Neco <a href="xneco.php"><b>Click Here</b></a></p>
<hr>
<p>For Nabteb <a href="xnabteb.php"><b>Click Here</b></a></p>
<hr>
<p>WAEC GCE JAN/FEB Exam <a href="xgce.php"><b>Click Here</b></a></p>
<hr>
<div style="display:none;">EMAIL: <a href="/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="a4e3cdc0cdc9c5d6c5cee4c3c9c5cdc88ac7cbc9">[email&#160;protected]</a></div>
<div style="display:none;"><p><a href="/manager/subscribers">Click Here To Confirm Your <b>WAEC</b> Details</a><br><span style="font-weight: bold; color: rgb(57, 123, 33);">Note: Already Subscribed Members Only!</span></p></div>
</div>
</div>

        <div class="space" style="margin:0px;">
            <b>
                <div class="main"><h1>HOT UPDATES</h1></div>
            </b>
        </div>
<div class="updates">
   
<?php
    #load updates
    $page_="";
    $q=$conn->query("SELECT * FROM updates ORDER BY id DESC LIMIT 10") or die($conn->error);
    if($q->num_rows==0){
        $page_="No update yet";
    } else {
        while($load=$q->fetch_object()){
            $uid=$load->id;
            $topic=$load->topic;
            $page_.='<i class="fas fa-long-arrow-alt-right"></i> <a href="view.php?id='.$uid.'">'.$topic.'</a><br><br>';
        }
    }
?>

<div class="updates">
    <?=$page_?>
</div>
</div>
<?php include "footer.php"; ?>