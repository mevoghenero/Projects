<?php include "content.php"; ?>
<br>
<div class="col-md-12 col-xs-12">
	<div class="well">
		<div align="center"><span style="font-weight: 700; font-family: sans-serif; font-size: medium; background-color: rgb(245, 245, 245);"><div class="bmenu" style="color: rgb(255, 255, 255); background-color: #087eb7; background-repeat: repeat-x; background-position: 50% top; margin-top: 1px; margin-bottom: 1px; padding: 2px; border: 1px solid rgb(224, 230, 255);"><h1>2019 JAMB CBT RUNS</h1></div></span></div>
		<div><span style="font-weight: bold; text-decoration-line: underline;"><br /></span></div>
		<div><span style="font-weight: bold; text-decoration-line: underline;">BENEFIT OF PAYMENT BEFORE EXAM:</span></div>
		<div>(i)You are automatically a VIP.</div>
		<div>(ii)You will be registered on our database&nbsp;where u can confirm ur subjects and reg number to make sure there is no mistake on your data</div>
		<div>(iii)You will get special attention from us.</div>
		<div>(iv)We can call or text you anytime if any update comes up.</div>
		<div>NOTE: The Price May increase, Early Payment is Good</div>
		<div><br /></div>
		<div><span style="text-decoration-line: underline; font-weight: bold;">LISTS OF AVAILABLE SUBJECTS FOR JAMB CBT RUNS</span></div>
		<div>English</div>
		<div>Maths</div>
		<div>Biology</div>
		<div>physics</div>
		<div>Chemistry</div>
		<div>Literature</div>
		<div>Govenment</div>
		<div>Geography</div>
		<div>Economics</div>
		<div>Commerce</div>
		<div>Accounting</div>
		<div>Agric</div>
		<div>CRK/IRK</div>
		<div><br /></div>


		<div><br /></div>
		<div>&nbsp;<span style="font-weight: bold; color: rgb(255, 0, 0);">WHAT YOU NEED TO KNOW</span>:- 
			<div> Don't miss this  opportunity, we are working tirelessly to make sure all our candidates score from 250+ and above in the upcoming CBT.  Jamb Cbt 2019 is going to be the best ever because we unveiled NEW STRATEGY to get access to the real questions and answers 4hrs before examination through your registration number. <br> <br>

				<p><b>NOTE:</b> Jamb questions and answers for candidate A is different from candidate B.  Know the right source today, your success is in your hand.</p> </div>
				<div><br /></div>

				<div><span style="color: rgb(255, 0, 0);">OUR PRICE TAG:</span>&nbsp;</div>
				<div>(i) 2 SUBJECTS:&nbsp;<span style="color: rgb(0, 0, 255);">N2,500</span></div>
				<div>(This is for those that need 2 subjects)</div>
				<div><br /></div>
				<div>(ii) 3 SUBJECTS:&nbsp;<span style="color: rgb(0, 0, 255);">N3,500</span></div>
				<div>(This is for those that need 3 subjects)</div>
				<div><br /></div>
				<div>(iii) 4 SUBJECTS:&nbsp;<span style="color: rgb(0, 0, 255);">N5,000</span></div>
				<div>(This is for those that need complete subjects, that is (4 subjects))</div>
				<div><br /></div>
				<div>(iiii) ALL SUBJECTS:&nbsp;<span style="color: rgb(0, 0, 255);">N30,000</span></div>
				<div>(This is for those that need all the subjects i.e Wapmasters, Center Owners (Those that have candidates)</div>
				<div><br /></div>
				<div>PAYMENT IS DONE THROUGH MTN CARDS ONLY !!</div>
				<div><br /></div>
				<div><span style="color: rgb(255, 0, 0);">HOW TO SUBSCRIBE:</span>&nbsp;</div>
				<div>Send the following to <b>07067172511</b>:</div>
				<div>(i) MTN CARD PINS (AIRTIME)&nbsp;</div>
				<div>(ii) Amount Paid (CHECK THR PRICE TAG ABOVE)</div>
				<div><br /></div>

				<div><span style="color: rgb(255, 0, 0);">REQUIREMENT AFTER PAYMENT:</span>&nbsp;</div>
				<div>
					- Your name <br>
					- Jamb Reg Number (you can skip this untill receive it from JAMB) <br>
					- Your Center <br>
					- Phone number <br>
					- Amount paid <br>
					- Subjects <br>
				</div>
				<div>&nbsp;</div>
				<div><span style="font-weight: bold; text-decoration-line: underline; color: rgb(255, 0, 0);">RUNS PATTERN</span>:</div>
				<div>==WE STRONGLY ADVICE OUR SUBSCRIBERS TO HAVE INTERNET ACCESS</div><br>
				<div>==ALL ANSWERS WILL BE UPDATED ON THIS SITE BEST ON YOUR REG NUMBER. NOTE, ONLY YOU CAN ACCESS YOUR ANSWERS.</div><br>
				<div>==YOU WILL RECEIVE CONFIRMATION TEXT IN THE NIGHT AFTER YOUR PAYMENT.</div><br>
				<div>==FOR WEBBMASTERS, CENTER OWNERS, THE MEAN TO GET YOUR ANSWERS IS WHATSAPP!</div><br>
				<div>==PLEASE QUOTE US RIGHT, WE CAN'T SEND ANSWERS AS SMS BECAUSE WE EXTRACT THIS VIA YOUR REG NUMBER WHICH WE CAN'T FORWARD AS SMS!</div> </div>

				<br>
				<div class="sharethis-inline-share-buttons"></div>

			</div>
		</div>

		<?php include("footer.php"); ?>