<?php
/* IMPORTANT FILES */
include "modules.php";

$pageTitle="examsss";
$err="";
include "content.php";
$edit="";

$examID=(int)$_GET['id'];
if(!$examID and isloggedin()){
    header("location:$domain/exams.php");
    exit;
} elseif(!$examID and !isloggedin()){
    header("location:$domain");
    exit;
}
else {
    if(isloggedin()){
        if(isset($_POST['sav'])){
            $content=$_POST['cnnt'];
            if(!$content){
                $err="Please type something";
            }
            else {
                $time=time();
                $conn->query("INSERT INTO examp SET poster='$who', post='$content', timedd=$time, examid=$examID") or die(mysqli_error($conn));
                echo "Post added!";
            }
        }
    }
$q=$conn->query("SELECT * FROM exam WHERE id=$examID") or die(mysqli_error($conn));
if(mysqli_num_rows($q)==0){
echo "<div style=\"color:red; font-size:32px;\">EXAM WITH THIS ID NOT FOUND</div>";
}
else {
    $ft=mysqli_fetch_object($q);
    $subject=$ft->subj;
    $pin=$ft->pass;
    $admp="";
    $closed=$ft->closed;
    if($closed==0)
        $clos_ed=<<<EOF
        <form method="post" action="">
        <input type="checkbox" value="1" name="xxop"> Close Exam <input type="submit" name="actt" value="Submit">
        </form>
EOF;
    else
        $clos_ed=<<<EOF
        <form method="post" action="">
        <input type="checkbox" value="0" name="xxop"> Open Exam <input type="submit" name="actt" value="Submit">
        </form>
EOF;

    if((!isloggedin()) and (!isset($_SESSION['pin']) or $_SESSION['pin']!==$pin)){
        header("location:$domain?error=xpin");
        exit;
    }
    if(isloggedin()){
        $admp="'$who' -- ";
        if(isset($_POST['actt'])){
            $exVAL=@$_POST['xxop'];
            $sql=$conn->query("UPDATE exam SET closed=$exVAL WHERE id=$examID") or die(mysqli_error($conn));
        }
    }
    $content=<<<EOF
    <div class="itemContainer">SUBJECT: <b>$subject</b> AND YOUR IS "<font color="slateblue"><b>$pin</b></font>"<br><br>
               <a onclick="window.location=window.location" href="#"><font color="#228b22"><b style="font-size:18px">REFRESH PAGE</b></font></a></div>
    
    
EOF;
//fetch contents
$q2=$conn->query("SELECT * FROM examp WHERE examid=$examID ORDER BY id DESC") or die(mysqli_error($conn));
if(mysqli_num_rows($q2)==0){
    echo "<div class=\"passwordEnter\"><h3>ANSWERS LOADING. PLEASE HOLD ON</div>";
}
else {
    while($pd=mysqli_fetch_object($q2)){
        $pid=$pd->id;
        $whop=$pd->poster;
        $post=bb_code($pd->post);
        $time=date("jS, F Y", $pd->timedd);
        if(isloggedin()){
            $edit="<br>[<a href=\"editor.php?id=$pid&action=edit\"><font color=\"crimson\">Edit</font></a>] [<a href=\"editor.php?id=$pid&action=del\"><font color=\"crimson\">Delete</font></a>]";
        }
        $content.=<<<EOF
        <div class="post">
            <font color="red"><div class="poster">$whop - $time</div></font>
            <div class="positem">
             <font color="red">==></font> $post
            </div>
            $edit
        </div>
<div class="itemContainer"><font color="red">Please Just Hold On... Keep Clicking The</font> <a onclick="window.location=window.location" href="#"><font color="#228b22"><b style="font-size:18px">REFRESH PAGE</b></font></a> <font color="red">So That Once We Drop It You Are Going To See It......</font></div>
EOF;
    }
}
if(isloggedin()){
    $content.=<<<EOF
    <div class="itemContainer center"><form method="post" action="">
    <div style="color:red; font-size:32px;">$err</div>
    Content:<br>
    <textarea style="width:85%;height:200px" name="cnnt"></textarea>
    <br><br><input type="submit" name="sav" value="Post Content">
    </form></div>
    <div class="itemContainer center"><b>Close Exam?</b><br>Note: If you close exam it will be unavailable for access by candidates.<br>
    $clos_ed
    </div>
EOF;
}
}
}
?>
<?=$content?>
<?php include "footer.php"; ?>